package dev.trindadedev.easyui.filepicker.controller;

public interface NotifyItemChecked {
    void notifyCheckBoxIsClicked();
}
