package dev.trindadedev.easyui.filepicker.controller;

public interface DialogSelectionListener {
    void onSelectedFilePaths(String files[]);
}
